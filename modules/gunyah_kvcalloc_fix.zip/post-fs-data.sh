#!/system/bin/sh
MODDIR=${0%/*}
LOG="/data/local/tmp/gunyah_kvcalloc.log"
KO="$MODDIR/system/lib/modules/gunyah_kvcalloc_mod.ko"

echo "$(date) === gunyah-kvcalloc-fix: loading ===" > "$LOG"
insmod "$KO" 2>> "$LOG"
if [ $? -eq 0 ]; then
    echo "$(date) SUCCESS: module loaded" >> "$LOG"
else
    echo "$(date) FAILED: insmod returned $?, trying force load..." >> "$LOG"
    insmod -f "$KO" 2>> "$LOG"
    if [ $? -eq 0 ]; then
        echo "$(date) SUCCESS: force loaded" >> "$LOG"
    else
        echo "$(date) FAILED: force load also failed" >> "$LOG"
    fi
fi
